def fibonacci(n):
    """Return the first n Fibonacci numbers, starting with 0, 1."""
    if n < 0:
        raise ValueError("n must be non-negative")
    sequence = []
    a, b = 0, 1

    for _ in range(n):
        sequence.append(a)
        a, b = b, a + b

    return sequence


if __name__ == "__main__":
    print(fibonacci(8))
