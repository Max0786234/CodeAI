def bubble_sort(nums):
    """Return a sorted copy of nums using bubble sort."""
    arr = nums[:]

    for end in range(len(arr) - 1, 0, -1):
        swapped = False
        for i in range(end):
            if arr[i] > arr[i + 1]:
                arr[i], arr[i + 1] = arr[i + 1], arr[i]
                swapped = True
        if not swapped:
            break

    return arr


if __name__ == "__main__":
    print(bubble_sort([5, 1, 4, 2, 8]))
