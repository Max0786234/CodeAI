def factorial_iterative(n):
    """Return n! for a non-negative integer n."""
    if n < 0:
        raise ValueError("n must be non-negative")

    result = 1
    for value in range(2, n + 1):
        result *= value
    return result


def factorial_recursive(n):
    """Return n! using recursion."""
    if n < 0:
        raise ValueError("n must be non-negative")
    if n <= 1:
        return 1
    return n * factorial_recursive(n - 1)


if __name__ == "__main__":
    print(factorial_iterative(5))
    print(factorial_recursive(5))
