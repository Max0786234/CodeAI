def linear_search(nums, target):
    """Return the first index of target, or -1 if absent."""
    for index, value in enumerate(nums):
        if value == target:
            return index
    return -1


if __name__ == "__main__":
    print(linear_search([4, 2, 7, 2], 2))  # 1
