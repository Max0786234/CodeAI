def two_sum(nums, target):
    """Return indices of two distinct elements that sum to target.
    Return an empty list if no pair exists.
    """
    seen = {}

    for index, value in enumerate(nums):
        needed = target - value
        if needed in seen:
            return [seen[needed], index]
        seen[value] = index

    return []


if __name__ == "__main__":
    print(two_sum([2, 7, 11, 15], 9))  # [0, 1]
