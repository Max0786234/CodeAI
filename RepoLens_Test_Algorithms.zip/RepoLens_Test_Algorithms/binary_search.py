def binary_search(nums, target):
    """Return the index of target in sorted nums, or -1 if not found."""
    left, right = 0, len(nums) - 1

    while left <= right:
        mid = (left + right) // 2

        if nums[mid] == target:
            return mid
        if nums[mid] < target:
            left = mid + 1
        else:
            right = mid - 1

    return -1


if __name__ == "__main__":
    print(binary_search([1, 3, 5, 7, 9], 7))  # 3
