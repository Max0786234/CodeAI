def is_palindrome(text):
    """Return True if text reads the same forward and backward,
    ignoring case, spaces, and punctuation.
    """
    cleaned = "".join(char.lower() for char in text if char.isalnum())
    return cleaned == cleaned[::-1]


if __name__ == "__main__":
    print(is_palindrome("A man, a plan, a canal: Panama"))
