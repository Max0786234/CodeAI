# RepoLens Test Repository: Easy Python Algorithms

This small repository is designed to test RepoLens code-upload and question-answering.

## Files
- `binary_search.py` — iterative binary search on a sorted list.
- `bubble_sort.py` — bubble sort with early stopping.
- `factorial.py` — iterative and recursive factorial.
- `fibonacci.py` — iterative Fibonacci sequence.
- `is_palindrome.py` — normalize text and check palindrome.
- `linear_search.py` — simple linear search.
- `two_sum.py` — return indices of two numbers that add to a target.
- `gcd.py` — Euclidean algorithm for greatest common divisor.

Ask RepoLens questions about function behavior, examples, edge cases, complexity, and how files relate.
